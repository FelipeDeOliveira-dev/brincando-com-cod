
const botaoEnviar = document.getElementById('enviar');
const coracoesContainer = document.getElementById('coracoes');

function criarCorações() {
    const numCorações = 50;  

    for (let i = 0; i < numCorações; i++) {
       
        const coracao = document.createElement('div');
        coracao.classList.add('coracao');
        coracao.innerHTML = '❤️';  
        
        const largura = window.innerWidth;  
        const altura = window.innerHeight;  
        coracao.style.left = `${Math.random() * largura}px`;  
        coracao.style.top = `${Math.random() * altura}px`;  
        coracao.style.animationDelay = `${Math.random() * 4}s`; 

       
        coracoesContainer.appendChild(coracao);

       
        setTimeout(() => {
            coracao.remove();
        }, 2000);  
    }
}


botaoEnviar.addEventListener('click', criarCorações);

